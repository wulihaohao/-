﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
namespace class7_1_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Form1.CheckForIllegalCrossThreadCalls = false;
        }
        List<Point> snake = new List<Point>();
        List<Point> eggs = new List<Point>();
        Keys direction = Keys.Right;
        Thread t1, t2;
        bool b1 = true;
        int fenshu = 0;
        private void 开始ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            direction = Keys.Right;
            fenshu = 0;
            t1 = new Thread(new ThreadStart(Begin));
            t1.Start();
            t2 = new Thread(new ThreadStart(RefreshEggs));
            t2.Start();
        }
        void RefreshEggs()
        {
            Graphics g = panel1.CreateGraphics();
            Random r1 = new Random();
            int x1 = r1.Next(0, 20) * 20;
            Thread.Sleep(39);
            int y1 = r1.Next(0, 20) * 20;
            Thread.Sleep(39);
            eggs.Add(new Point(x1, y1));
            g.FillEllipse(new SolidBrush(Color.Red), x1, y1, 20, 20);
            while (true)
            {
                if(b1==false)
                {
                for (int i = 0; i < eggs.Count; i++)
                {
                    g.FillEllipse(new SolidBrush(panel1.BackColor), eggs[i].X, eggs[i].Y, 20, 20);
                }
                eggs.Clear();
                //for (int i = 0; i < 3; i++)
                //{
                    Random r = new Random();
                    int x = r.Next(0, 20)*20;
                    Thread.Sleep(39);
                    int y = r.Next(0, 20) * 20;
                    Thread.Sleep(39);
                    eggs.Add(new Point(x,y));
                    g.FillEllipse(new SolidBrush(Color.Red), x, y, 20, 20);
                //}
                    //Thread.Sleep(5000);
                b1 = true
;
                }
                else
                {

                }
            }
        }
        void Begin()
        {
            snake.Add(new Point(60, 20));
            snake.Add(new Point(40, 20));
            snake.Add(new Point(20, 20));
            Graphics g = panel1.CreateGraphics();
            while (true)
            {
                g.FillRectangle(new SolidBrush(panel1.BackColor), snake[snake.Count - 1].X, snake[snake.Count - 1].Y, 20, 20);
                for (int i = snake.Count - 1; i > 0; i--)
                {
                    snake[i]=snake[i-1];
                    g.FillRectangle(new SolidBrush(Color.Green), snake[i].X, snake[i].Y, 20, 20);
                }
                switch(direction)
                {
                    case Keys.Right :
                        snake[0] =new Point(snake[0].X +20,snake[0].Y);
                        break;
                    case Keys.Left:
                        snake[0] = new Point(snake[0].X - 20, snake[0].Y);
                        break;
                    case Keys.Down:
                        snake[0] = new Point(snake[0].X, snake[0].Y + 20);
                        break;
                    case Keys.Up:
                        snake[0] = new Point(snake[0].X, snake[0].Y - 20);
                        break;

                }
                if (snake[0].X >= 400 || snake[0].X < 0 || snake[0].Y >= 400 || snake[0].Y < 0)
                {
                    t2.Abort();
                    Thread.Sleep(100);
                    MessageBox.Show("游戏结束！");
                    snake.Clear();
                    eggs.Clear();
                    defen.Text ="0";
                    g.Clear(panel1.BackColor);
                    t1.Abort();
                  
              
                }
                for (int i = 1; i < snake.Count; i++)
                {
                    if (snake[0].X == snake[i].X && snake[0].Y == snake[i].Y)
                    {
                        t2.Abort();
                        Thread.Sleep(100);
                        MessageBox.Show("游戏结束！");
                        snake.Clear();
                        eggs.Clear();
                        defen.Text = "0";
                        g.Clear(panel1.BackColor);
                        t1.Abort();
                       

                    }
                }
                g.FillEllipse(new SolidBrush(Color.Green), snake[0].X, snake[0].Y,20,20);
                for (int i = 0; i < eggs.Count; i++)
                {
                    if (snake[0].X == eggs[i].X && snake[0].Y == eggs[i].Y)
                    {
                        fenshu += 1;
                        defen.Text = fenshu.ToString();
                        b1 = false;
                        Point eg1 = new Point();
                        if (snake.Count == 3)
                        {
                            switch (direction)
                            {
                                case Keys.Right:
                                    eg1.X = snake[0].X - 20;
                                    eg1.Y = snake[0].Y;
                                    break;
                                case Keys.Left:
                                    eg1.X = snake[0].X + 20;
                                    eg1.Y = snake[0].Y;
                                    break;
                                case Keys.Up:
                                    eg1.X = snake[0].X;
                                    eg1.Y = snake[0].Y + 20;
                                    break;
                                case Keys.Down:
                                    eg1.X = snake[0].X;
                                    eg1.Y = snake[0].Y - 20;
                                    break;

                            }
                        }
                        else
                        {
                            if(snake[snake.Count-1].X<snake[snake.Count-2].X)
                            {
                                eg1.X = snake[snake.Count - 1].X - 20;
                                eg1.Y = snake[snake.Count - 1].Y;
                            }
                            if (snake[snake.Count - 1].X < snake[snake.Count - 2].X)
                            {
                                eg1.X = snake[snake.Count - 1].X + 20;
                                eg1.Y = snake[snake.Count - 1].Y;
                            }
                            if (snake[snake.Count - 1].Y < snake[snake.Count - 2].Y)
                            {
                                eg1.X = snake[snake.Count - 1].X;
                                eg1.Y = snake[snake.Count - 1].Y +20;
                            }
                            if (snake[snake.Count - 1].Y < snake[snake.Count - 2].Y)
                            {
                                eg1.X = snake[snake.Count - 1].X;
                                eg1.Y = snake[snake.Count - 1].Y - 20;
                            }
                        }
                        snake.Add(eg1);
                    }
                }
                
                
                Thread.Sleep(200);
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            direction = e.KeyCode;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 结束ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            t2.Abort();
            t1.Abort();
            snake.Clear();
            eggs.Clear();
            Graphics g = panel1.CreateGraphics();
            g.Clear(panel1.BackColor);
        }
    }
}
